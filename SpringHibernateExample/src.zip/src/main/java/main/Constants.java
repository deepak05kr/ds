package main;

public class Constants {

	public static final String SAVING = "saving";
	public static final String CURRENT = "current";

}
