package game;

public class MatchCompleteState extends CarromState  {

}
